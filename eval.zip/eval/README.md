# Eval LLM RATP
## Install  deps & repo

### Install deps
```bash
poetry install
```

## Run langfuse (& postgres local)
CHECK the docker-compose.yml file (env variables, ports) before.
```bash
#docker-compose -f docker-compose-local.yml up -d
make docker
```

## Prod
### CREATE DB
psql to go in the server.
```
create database [DB_NAME]
```


### For the first time
- Please sign up (you will be the admin if nobody is in the database).
- Please create a project or join a project
- Please create api keys or retrieve the keys (secret and public)
- Add these keys in the eval .env file (LANGFUSE_PUBLIC_KEY, LANGFUSE_SECRET_KEY)


## Create the dataset in langfuse
You can modify the file `dataset_adapter.py` to import your data with pandas.  
You can modify the file `langfuse/create_dataset.py` too.  
You must have three columns:
- source_name: str
- question: str
- ground_truths: list[str]
- ground_truth_contexts: list[str]
- ground_truth_documents: list[str]

You can add the dataset in langfuse with this command :
```python
from eval_llm_ratp.main import create_dataset
create_dataset("FILENAME", "DATASET_NAME")
```

You can go to the langfuse web app, to see the new dataset.

## Evaluation

### Evaluate
```python
from eval_llm_ratp.main import run_eval
run_eval("EXPERIMENT", "DATASET_NAME")
```

#### Filter by source name
```python
from eval_llm_ratp.main import run_eval
run_eval("EXPERIMENT", "DATASET_NAME",filter_source=["SOURCE_NAME"])
```
You can go to the langfuse web app, to see the new dataset run.


## Structure
```
langfuse/  

        create_dataset.py -> create the dataset in langfuse  
        callback_handler.py ->  handle the start and end of certain processing chains, with specific attention to conditionally skipping callbacks based on naming conventions.

ragas/  
        chains/ -> the custom chains
        metrics/ -> the custom metrics  
        processing.py -> The class to allow pre and post processing for the metrics (usefull to create/update langfuse span)  
        ragas_langfuse_decorator -> Decorator of ragas metric to allow pre/post processing with metrics & use langfuse callback  
        metrics_integration.py -> Specific code by metrics to create/update span  

dataset_adapter.py -> The function where you update your dataset to conform langfuse/ragas specs  
models.py -> The code to get the RAG pipeline  
eval.py -> The main class to evaluate the dataset with the metrics. (get metrics, get rag pipeline, create langfuse traces, get scores)  
main.py -> The main entrypoint to the eval (create_dataset method & run_eval method)
settings.py -> The global environement settings (depending on Cloud Provider)  

docker-compose.yml -> create two container: langfuse (server and web) & postgres  
```

### Metrics
There are three types of metrics:
- With ground_truth
- With RAG
- Textual

#### Ground-Truth metrics
**Retrieval Performance**:

The implemented metrics to evaluate the retrieval performance are the following :
- *retrieve_document_accuracy* : calculates the percentage of retrieved documents (or chunks of documents) that are mentioned in the Ground-Truth sources (~ Precision). It supports evaluation in two modes: DOC and CHUNK :
        - DOC: Calculates the percentage of unique retrieved documents that are also in the Ground-Truth documents.
        - CHUNK: Calculates the percentage of retrieved chunks that match the Ground-Truth documents.

        Example :
                ground_truth_documents = [Doc_A, Doc_C]

                retrieved_chunks = [Doc_A, Doc_A, Doc_A, Doc_A, Doc_A, Doc_B, Doc_C]

                retrieved_documents = [Doc_A, Doc_B, Doc_C]

                retrieve_document_accuracy (DOC) = len(retrieved_documents & ground_truth_documents) / len(retrieved_documents) = 2 / 3

                retrieve_document_accuracy (CHUNK) = sum(retrieved_chunks & ground_truth_documents) / len(retrieved_chunks) = 6 / 7

- *retrieve_document_completeness* : calculates a completeness score. It is the ratio of the number of Ground-Truth documents present in the chatbot answer to the total number of Ground-Truth documents (~ Recall).

        Example :
                ground_truth_documents = [Doc_A, Doc_C]

                retrieved_chunks = [Doc_A, Doc_A, Doc_A, Doc_A, Doc_A, Doc_B, Doc_C]

                retrieved_documents = [Doc_A, Doc_B, Doc_C]

                retrieve_document_completeness =  len(set(retrieved_documents) & set(ground_truth_documents)) / len(set(ground_truth_documents)) = 2 / 2

                len(retrieved_documents & ground_truth_documents) / len(retrieved_documents) = 1 / 2


- **Answer Performance** :
        Currently we use an LLM judge (gpt-4) to evaluate the quality of the chatbot's answers compared to the Ground-Truth, a score of performance is assigned on a scale from 1 to 5.  


## Dev
### Run pre-commit
```bash
poetry run pre-commit
```
#### all files
```bash
poetry run pre-commit run --all-files
```
