import random
import string
import time
from datetime import datetime

import numpy as np
import openai
import tqdm
from dotenv import load_dotenv
from langchain.schema.runnable.config import RunnableConfig
from langfuse import Langfuse
from langfuse.client import DatasetItemClient
from ragas import __version__ as RAGAS_VERSION
from ragas.llms import LangchainLLMWrapper

from iagen.factory import Factory
from iagen.managers.schema import Provider
from iagen.settings import settings

from .langfuse.callback_handler import CallbackHandler
from .models import get_pipeline
from .ragas.metrics_integration import (
    AnswerAccuracyWithProcessing,
    ContextDocumentAccuracyWithProcessing,
    ContextDocumentCompletenessWithProcessing,
    RetrieveDocumentAccuracyWithProcessing,
    RetrieveDocumentCompletenessWithProcessing,
    global_ragas_scores,
    score_with_ragas,
)
from .ragas.ragas_langfuse_decorator import MetricRagasLangfuseDecorator

load_dotenv()
LIB_VERSIONS = {"ragas": RAGAS_VERSION}


def calculate_scores(
    metrics: dict,
    item: DatasetItemClient,
    context: list[str],
    sources_context: list[str],
    answer: str,
    cb_scores: CallbackHandler,
) -> dict:
    scores = {"ragas": score_with_ragas(metrics["ragas"], item, context, sources_context, answer, cb_scores)}
    return scores


def get_metrics() -> dict:
    # metrics you chose
    gpt4 = Factory.get_llm(
        provider=Provider.AZURE,
        deployment_name=settings.OPENAI_GPT4_TURBO_DEPLOYMENT_NAME,
        model="gpt-4-1106-preview",
    )
    metrics_ragas = [
        MetricRagasLangfuseDecorator(metric=AnswerAccuracyWithProcessing()),
        MetricRagasLangfuseDecorator(metric=RetrieveDocumentAccuracyWithProcessing()),
        MetricRagasLangfuseDecorator(metric=RetrieveDocumentCompletenessWithProcessing()),
        MetricRagasLangfuseDecorator(metric=ContextDocumentAccuracyWithProcessing()),
        MetricRagasLangfuseDecorator(metric=ContextDocumentCompletenessWithProcessing()),
    ]
    for m in metrics_ragas:
        m.init(LangchainLLMWrapper(gpt4))

    return {"ragas": metrics_ragas}


def get_random_string(length):
    # choose from all lowercase letter
    letters = string.ascii_lowercase
    return "".join(random.choice(letters) for i in range(length))  # noqa: S311


def should_include_item(item, filter_source):
    filter_source_lower = [i.lower() for i in filter_source]
    return item.input["source_name"].lower() in filter_source_lower


def run_eval(
    experiment_name: str,
    dataset_name: str,
    n_runs: int = 3,
    filter_source: list[str] | None = None,
) -> None:
    print("Set-up pipeline...")
    bot = get_pipeline()

    print("Set-up metrics...")
    metrics = get_metrics()
    langfuse = Langfuse(timeout=120)
    dataset = langfuse.get_dataset(dataset_name)

    total = sum(1 for item in dataset.items if should_include_item(item, filter_source))

    for item_ind, item in tqdm.tqdm(enumerate(dataset.items), desc="tests", leave=True, total=total):
        if not should_include_item(item, filter_source):
            print(f"\tSKIP: {item_ind}")
            continue
        session_id = get_random_string(10)
        metadata = {
            "dataset_item_id": item.id,
            "run_name": experiment_name,
            "dataset_id": item.dataset_id,
        }

        # Create the item trace
        trace = langfuse.trace(name="dataset-rag-run", metadata=metadata, session_id=session_id)

        span_rag_global = trace.span(
            name="dataset-rag-run-span",
            input={
                "question": item.input["question"],
                "source_name": item.input["source_name"],
            },
            metadata=metadata,
            startTime=datetime.now(),
        )

        span_global_eval = trace.span(
            name="rag-eval-global",
            metadata={
                **metadata,
                "metrics": {
                    "ragas": [m.name for m in metrics["ragas"]],
                    "system": "latency",
                },
            },
            startTime=datetime.now(),
        )

        ragas_scores = []
        rag_answers = []
        rag_sources = []
        rag_context_sources = []
        rag_latencies = []

        for i in tqdm.tqdm(range(n_runs), desc="runs", position=1, leave=False):
            # Create the RAG span of run {i}
            span_rag = span_rag_global.span(
                name=f"dataset-rag-run-span-{i}",
                input={
                    "question": item.input["question"],
                    "source_name": item.input["source_name"],
                },
                metadata=metadata,
                startTime=datetime.now(),
            )

            cb_rag = CallbackHandler(stateful_client=span_rag, session_id=session_id)

            inputs = {"question": item.input["question"], "chat_history": []}

            res = None
            # Run RAG on inputs

            start_run = time.time()
            try:
                res = bot.invoke(
                    inputs,
                    config=RunnableConfig(
                        callbacks=[cb_rag],
                        configurable={"session_id": get_random_string(10)},
                    ),
                )
                sources = res.source_documents
                sources_context = res.context_documents
                rag_sources.append(sources)
                rag_context_sources.append(sources_context)
            except openai.BadRequestError as e:
                print(f"item: {item}", f"OPENAI ERROR '{e}")
                span_rag = span_rag.update(
                    output={
                        "contexts": sources,
                        "context_source": sources_context,
                        "error": f"OPENAI ERROR '{e}",
                    },
                    endTime=datetime.now(),
                )
            except Exception as e:
                raise e
            rag_latency = time.time() - start_run
            rag_latencies.append(rag_latency)

            # Get RAG answer
            answer = res.answer
            rag_answers.append(answer)

            # Update the main span with the outputs
            span_rag = span_rag.update(
                output={"contexts": sources, "answer": answer},
                endTime=datetime.now(),
            )

            # Create evaluation span for run {i}
            span_eval_i = span_global_eval.span(
                name=f"rag-eval-{i}",
                startTime=datetime.now(),
                input={
                    "answer": answer,
                },
            )
            cb_scores = CallbackHandler(stateful_client=span_eval_i, session_id=session_id)  # create the langfuse callback

            scores = None
            try:
                # calculate Ragas scores
                scores = calculate_scores(metrics, item, sources, sources_context, answer, cb_scores)
                ragas_scores.append(scores)
            except openai.BadRequestError as e:
                print(f"calculate_scores: item: {item}", f"OPENAI ERROR '{e}")
                span_eval_i.update(
                    output={"error": f"ERROR openai '{e}'"},
                    endTime=datetime.now(),
                )
                continue
            except Exception as e:
                raise e

            # send the scores to langfuse along with latency
            for lib, scores_for_lib in scores.items():
                comment = f"{lib}=={LIB_VERSIONS[lib]}"
                for score_name, score in scores_for_lib.items():
                    span_eval_i.score(name=score_name, value=score, comment=comment)

            span_eval_i.score(name="latency", value=rag_latency)

        # Create the global evaluation span
        span_global_eval.update(
            input={
                "question": item.input["question"],
                "contexts": rag_sources,
                "sources_context": rag_context_sources,
                "answer": rag_answers,
                "expected_output": item.expected_output,
            },
        )
        item.link(span_global_eval, experiment_name)

        global_scores = global_ragas_scores(ragas_scores)
        global_scores["rag_latency_mean"] = np.mean(rag_latencies)

        # send the scores to langfuse
        for score_name, score in global_scores.items():
            span_global_eval.score(name=score_name, value=score)

        # update the main span with the scores
        span_global_eval.update(
            output={"scores": global_scores},
            endTime=datetime.now(),
        )
