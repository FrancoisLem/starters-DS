def normalize(txt) -> str:
    """Normalize the text.

    Parameters
    ----------
    txt
        The text to normalize

    Returns
    -------
    str
        The text normalized
    """
    return txt.strip().replace("-", "").replace(" ", "").strip()
