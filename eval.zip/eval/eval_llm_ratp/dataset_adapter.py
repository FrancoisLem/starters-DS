import pandas as pd


def create_dataset(filename: str, sheet_name: str = "Feuil1") -> pd.DataFrame:
    """
    Read an Excel file and preprocess the data into a structured DataFrame.

    Parameters
    ----------
    filename
        The path to the Excel file to read data from.
    sheet_name
        The name of the sheet within the Excel file to read data from.

    Returns
    -------
        A DataFrame containing the cleaned and preprocessed data.
    """

    data = pd.read_excel(filename, sheet_name=sheet_name)
    data = data.dropna()
    data_qa = pd.DataFrame(data)
    data_qa.columns = [
        "source_name",
        "question",
        "ground_truths",
        "ground_truth_contexts",
    ]

    # Wrap 'ground_truths' and 'ground_truth_contexts' into lists
    data_qa["ground_truth_contexts"] = data_qa["ground_truth_contexts"].apply(
        lambda a: [i.strip() for i in a.split("\n") if len(i.strip()) > 0]
    )
    data_qa["ground_truths"] = data_qa["ground_truths"].apply(lambda a: [a])
    return data_qa.reset_index(drop=True)
