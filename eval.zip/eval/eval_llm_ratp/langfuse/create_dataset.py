"""
This module is designed to create datasets in Langfuse using data provided in a pandas DataFrame.
It utilizes the `Langfuse` API to create a new dataset and populate it with items from the DataFrame.
The module requires the `.env` file to be loaded at runtime to access necessary environment variables.

"""

from typing import TYPE_CHECKING

from dotenv import load_dotenv
from langfuse import Langfuse

if TYPE_CHECKING:
    import pandas as pd

load_dotenv()
langfuse = Langfuse()


def create_dataset_langfuse(items: "pd.DataFrame", name: str) -> None:
    """
    Create a dataset in Langfuse with the given name and populate it with items from the provided DataFrame.

    Parameters
    ----------
    items
        A pandas DataFrame containing the data to be uploaded to Langfuse.
        The DataFrame must include columns named 'question', 'source_name', 'ground_truth_contexts', and 'ground_truths'.
    name
        The name of the dataset to be created in Langfuse.

    Notes
    -----
    The function relies on the environment variables for Langfuse API authentication.
    Ensure that the necessary credentials are provided in the `.env` file before calling this function.
    """

    langfuse.create_dataset(name=name)

    # Upload to Langfuse
    for _, item in items.iterrows():
        langfuse.create_dataset_item(
            dataset_name=name,
            input={"question": item["question"], "source_name": item["source_name"]},
            expected_output={
                "ground_truth_contexts": item["ground_truth_contexts"],
                "ground_truths": item["ground_truths"],
            },
        )
