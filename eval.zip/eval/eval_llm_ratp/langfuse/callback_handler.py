"""
A module for handling callbacks in processing chains with the capability to skip
certain callbacks based on predefined conditions.

Notes:
    This module extends the functionality of OriginalCallbackHandler from langfuse.callback,
    allowing for more fine-tuned control over which runs invoke callbacks based on dynamic
    conditions like tags or specific run IDs.
"""

import typing as t
from uuid import UUID

from langfuse.callback import CallbackHandler as OriginalCallbackHandler


class CallbackHandler(OriginalCallbackHandler):
    """
    Handles callbacks specifically for operations within a processing chain, with
    additional functionality to skip callbacks based on the run's metadata or name.

    This class extends the OriginalCallbackHandler to introduce mechanisms for
    optionally skipping callbacks for certain runs, providing a flexible approach to
    handling start and end events in a chain of operations.

    Attributes
    ----------
    _skipped_run_id
        A list that keeps track of run IDs for which callbacks are to be skipped.

    Methods
    -------
    on_chain_start(serialized, inputs, *, run_id, parent_run_id=None, tags=None, metadata=None, **kwargs)
        Invoked at the start of a chain of operations, allowing for conditional skipping of the callback.
    on_chain_end(outputs, *, run_id, parent_run_id=None, **kwargs)
        Invoked at the end of a chain of operations, respecting any skips that were indicated at the start.
    """

    def on_chain_start(
        self,
        serialized: dict[str, t.Any],
        inputs: dict[str, t.Any],
        *,
        run_id: UUID,
        parent_run_id: t.Optional[UUID] = None,
        tags: t.Optional[list[str]] = None,
        metadata: t.Optional[dict[str, t.Any]] = None,
        **kwargs: t.Any,
    ) -> t.Any:
        """
        Invoked at the start of a chain of operations. It checks if the run should be skipped
        based on its name containing a specific tag. If not skipped, it proceeds with the usual
        callback process.

        Parameters
        ----------
        serialized
            Serialized data relevant to the operation.
        inputs
            Input data for the operation.
        run_id
            Unique identifier for the current operation run.
        parent_run_id
            Identifier for the parent run of the current operation, by default None.
        tags
            List of tags associated with the run, by default None.
        metadata
            Additional metadata for the run, by default None.
        **kwargs
            Arbitrary keyword arguments.

        Returns
        -------
        Any
            The result of the on_chain_start callback, if not skipped.

        Notes
        -----
        Skips the callback if the run's name contains '[skip_callback]'.

        Examples
        --------
        >>> handler = CallbackHandler()
        >>> handler.on_chain_start({'name': 'process'}, {'input': 'data'}, run_id=UUID('12345678-1234-5678-1234-567812345678'))
        This example would trigger the callback unless the name contains '[skip_callback]'.
        """
        name = kwargs.get("name", serialized.get("name", serialized.get("id", ["<unknown>"])[-1]))

        if not hasattr(self, "_skipped_run_id"):
            self._skipped_run_id = []

        if name is not None and "[skip_callback]" in name:
            self._skipped_run_id.append(run_id)
        else:
            return super().on_chain_start(
                serialized,
                inputs,
                run_id=run_id,
                parent_run_id=parent_run_id,
                tags=tags,
                metadata=metadata,
                **kwargs,
            )

    def on_chain_end(
        self,
        outputs: dict[str, t.Any],
        *,
        run_id: UUID,
        parent_run_id: t.Optional[UUID] = None,
        **kwargs: t.Any,
    ) -> t.Any:
        """
        Invoked at the end of a chain of operations. It checks if the run was marked to skip
        its callback during the start and if not, proceeds with the usual callback process.

        Parameters
        ----------
        outputs
            Output data from the operation.
        run_id
            Unique identifier for the current operation run.
        parent_run_id
            Identifier for the parent run of the current operation, by default None.
        **kwargs
            Arbitrary keyword arguments.

        Returns
        -------
        Any
            The result of the on_chain_end callback, if not skipped.

        Notes
        -----
        If the run was marked to skip during `on_chain_start`, it is ignored here.

        Examples
        --------
        >>> handler = CallbackHandler()
        >>> handler.on_chain_end({'output': 'data'}, run_id=UUID('12345678-1234-5678-1234-567812345678'))
        This example would trigger the callback unless the run was previously marked to skip.
        """
        if hasattr(self, "_skipped_run_id") and run_id in self._skipped_run_id:
            self._skipped_run_id.remove(run_id)
        else:
            return super().on_chain_end(outputs, run_id=run_id, parent_run_id=parent_run_id, **kwargs)
