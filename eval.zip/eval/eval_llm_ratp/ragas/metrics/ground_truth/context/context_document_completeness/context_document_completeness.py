from __future__ import annotations

import typing as t
from dataclasses import dataclass

from ragas.metrics.base import EvaluationMode

from eval_llm_ratp.ragas.metrics.ground_truth.retrieve.retrieve_document_completeness.retrieve_document_completeness import (
    RetrieveDocumentCompleteness,
)

if t.TYPE_CHECKING:
    from langchain_core.callbacks import Callbacks
    from ragas.run_config import RunConfig


@dataclass
class ContextDocumentCompleteness(RetrieveDocumentCompleteness):
    """
    Metric to evaluate the completeness of retrieved documents relative to the ground truth sources.

    This metric computes the percentage of ground truth documents that are present in the
    retrieved contexts documents.

    Attributes
    ----------
    name
        The metric name.
    evaluation_mode
        The evaluation mode.
    batch_size
        The batch size.

    """

    name: str = "context_document_completeness"
    evaluation_mode: EvaluationMode = EvaluationMode.gc
    batch_size: int = 15

    @t.override
    async def _ascore(self, row: dict, callbacks: Callbacks, is_async: bool) -> float:
        """
        Asynchronously compute the completeness score for a given row of data.

        This method extracts the ground truth and context documents from the input row,
        and calculates the percentage of ground truth documents that are found in the context
        documents.

        Parameters
        ----------
        row
            A dictionary containing the 'contexts' and 'ground_truths' keys.

        Returns
        -------
            The completeness score, defined as the ratio of the number of ground truth documents
            present in the contexts documents to the total number of ground truth documents.

        Notes
        -----
        The function assumes there is only one set of ground truths and that the URLs of the
        documents are used to identify them. It compares the paths of the URLs to determine
        the presence of ground truth documents in the contexts.
        """
        return await super()._ascore(
            {**row, "contexts": row["sources_context"]},
            callbacks=callbacks,
            is_async=is_async,
        )

    def init(self, run_config: RunConfig):
        pass


context_document_completeness = ContextDocumentCompleteness()
