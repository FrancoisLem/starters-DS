from __future__ import annotations

import typing as t
from dataclasses import dataclass
from enum import Enum

from ragas.metrics.base import EvaluationMode

from eval_llm_ratp.ragas.metrics.ground_truth.retrieve.retrieve_document_accuracy.retrieve_document_accuracy import (
    RetrieveDocumentAccuracy,
)

if t.TYPE_CHECKING:
    from langchain_core.callbacks import Callbacks
    from ragas.run_config import RunConfig


class Mode(Enum):
    DOC = "doc"
    CHUNK = "chunk"


@dataclass
class ContextDocumentAccuracy(RetrieveDocumentAccuracy):
    """
    Metric to evaluate the accuracy of retrieved documents against ground truth documents.

    This metric calculates the percentage of retrieved documents (or chunks of documents)
    that are mentioned in the ground truth set. It supports evaluation in two modes: DOC and CHUNK.

    Attributes
    ----------
    name
        The metric name.
    evaluation_mode
        The evaluation mode.
    mode
        The mode of operation, determining whether to evaluate based on entire documents (DOC) or chunks of documents (CHUNK).
    batch_size
        The batch size.

    """

    name: str = "context_document_accuracy"
    evaluation_mode: EvaluationMode = EvaluationMode.gc
    mode: Mode = Mode.CHUNK
    batch_size: int = 15

    @t.override
    async def _ascore(self, row: dict, callbacks: Callbacks, is_async: bool) -> float:
        """
        Asynchronously calculates the accuracy score for a given set of retrieved documents or chunks.

        Parameters
        ----------
        row
            A dictionary containing the contexts and ground truths for evaluation.

        Returns
        -------
        float
            The calculated accuracy score.

        Notes
        -----
        The accuracy score calculation differs based on the selected mode:
        - DOC: Calculates the percentage of unique retrieved documents that are also in the ground truth documents.
        - CHUNK: Calculates the percentage of retrieved chunks that match the ground truth documents.

        The function assumes there is only one set of ground truths and that the URLs of the
        documents are used to identify them. It compares the paths of the URLs to determine
        the presence of ground truth documents in the contexts.
        """
        return await super()._ascore(
            {**row, "contexts": row["sources_context"]},
            callbacks=callbacks,
            is_async=is_async,
        )

    def init(self, run_config: RunConfig):
        pass


context_document_accuracy = ContextDocumentAccuracy()
