from __future__ import annotations

import typing as t
from dataclasses import dataclass

from ragas.metrics.base import EvaluationMode, MetricWithLLM

from eval_llm_ratp.ragas.chains.evaluate_llm.evaluate_llm import EvaluateLLM

if t.TYPE_CHECKING:
    from langchain.callbacks.base import Callbacks


@dataclass
class AnswerAccuracy(MetricWithLLM):
    """
    Metric that returns the accuracy score of the chatbot answer compared to the ground truth.

    Attributes
    ----------
    name
        The metric name.
    evaluation_mode
        The evaluation mode.
    batch_size
        The batch size.

    """

    name: str = "answer_accuracy"
    evaluation_mode: EvaluationMode = EvaluationMode.qga
    batch_size: int = 15

    @t.override
    async def _ascore(self, row: dict, callbacks: Callbacks, is_async: bool) -> float:
        """
        Asynchronously calculates the accuracy score of the chatbot's answer.

        This method takes a single row of data, which must include a question, the chatbot's
        answer, and the ground truths. It uses an external LLM evaluator to rate
        the answer's accuracy against the ground truths. Currently, it considers only the
        first ground truth for evaluation.

        Parameters
        ----------
        row
            A dictionary containing the keys 'question', 'answer', and 'ground_truths', where
            'ground_truths' is expected to be a dictionary with a key 'ground_truths' that maps
            to a list of ground truth strings.
        callbacks
            A callbacks object that allows interaction with external services or hooks during
            evaluation, if necessary.

        Returns
        -------
            The score rated by the LLM judge.
        """
        question, answer, ground_truths = (
            row["question"],
            row["answer"],
            row["ground_truths"],
        )
        # assume only one ground_truths
        ground_truth = ground_truths["ground_truths"][0]

        answer_evaluator = EvaluateLLM(llm=self.llm)

        inputs = {"question": question, "answer": answer, "ground_truth": ground_truth}
        res_json = await answer_evaluator.generate(inputs, callbacks=callbacks)
        rate = int(res_json["rating"])

        # Scoring
        score = rate

        return score


answer_accuracy = AnswerAccuracy()
