from __future__ import annotations

from dataclasses import dataclass, field

from ..base import JsonBaseChain
from .prompts import EVAL_PROMPT


@dataclass
class EvaluateLLM(JsonBaseChain):
    """
    LLM-based evaluation to assess the quality of RATPBot answers compared to ground truth answers.
    It generates a JSON format output with the following main keys :
        - 'reasoning' : explication that led to the rating score.
        - 'rating' : the given score that ranges from 1 to 5.
    """

    prompt_system: str = EVAL_PROMPT
    DATASET_REQUIRED_KEYS: set[str] = field(default_factory=lambda: {"question", "ground_truth", "answer"})
    MODEL_REQUIRED: str = "gpt-4"
