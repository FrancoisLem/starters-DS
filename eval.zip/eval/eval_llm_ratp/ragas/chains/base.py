"""
This module defines the base classes and functionalities for constructing prompt-based chains
with LLMs and processing their outputs, with a specific focus on JSON data.

Classes
-------
BaseChain
    A base class for constructing prompts and processing LLM outputs, serving as the foundation for more specialized chain implementations.
JsonBaseChain
    Extends BaseChain to handle JSON data, incorporating a specialized output parser to manage and correct JSON structures.

"""

from __future__ import annotations

import re
import typing as t
from dataclasses import dataclass, field

from langchain.prompts import ChatPromptTemplate
from langchain_core.outputs import LLMResult
from ragas.llms import llm_factory
from ragas.llms.json_load import json_loader

from .utils import only_keep_specified_keys_in_dict

if t.TYPE_CHECKING:
    from langchain.callbacks.base import Callbacks
    from langchain.schema import BasePromptTemplate
    from langchain_core.prompt_values import PromptValue
    from ragas.llms import BaseRagasLLM


async def default_output_parser(text: str) -> str:
    """Default output parser that simply returns the input text."""
    return text


@dataclass
class BaseChain:
    """
    A base class that wraps prompt-based chains to be used for Ragas Evaluation.
    It facilitates the construction of prompts and the interpretation of LLM outputs.
    """

    prompt_system: str = ""
    prompt: BasePromptTemplate = field(init=False)
    llm: BaseRagasLLM = field(default_factory=llm_factory)
    output_parser: t.Callable[[str], t.Any] = default_output_parser

    verbose: bool = False

    # Required keys for input datasets
    DATASET_REQUIRED_KEYS: set[str] = field(default_factory=set)

    # A regex pattern that the model name must match, if specified
    MODEL_REQUIRED: t.Optional[str] = None

    @property
    def name(self) -> str:
        """
        Returns the class name.
        """
        return self.__class__.__name__

    def build_prompt(self, inputs: dict) -> PromptValue:
        """
        Constructs a prompt using the provided inputs and the prompt system.

        Parameters
        ----------
        inputs
            The inputs used to construct the prompt.

        Returns
        -------
            The constructed prompt.
        """
        inputs_list_required_keys = only_keep_specified_keys_in_dict([inputs], self.DATASET_REQUIRED_KEYS)

        return ChatPromptTemplate.from_messages([("system", self.prompt_system)]).format_prompt(**inputs_list_required_keys[0])

    def _checks_dataset_required_keys(self, data_list: list[dict]) -> None:
        """
        Checks if the provided dataset contains all required keys.

        Parameters
        ----------
        data_list
            The dataset to check.

        Raises
        ------
        Exception
            If any required keys are missing from the dataset.
        """
        for ind, data in enumerate(data_list):
            missing_keys = self.DATASET_REQUIRED_KEYS - set(data.keys())
            if missing_keys:
                raise Exception(
                    f"[eval_llm_ratp.ragas.chains.{self.name}.run] missing keys ({missing_keys}) "
                    f"in the data (row: {ind}). (required keys: '{self.DATASET_REQUIRED_KEYS}')"
                )

    def _checks_model_required(self) -> None:
        """
        Checks if the model name matches the required pattern, if specified.

        Raises
        ------
        Exception
            If the model name does not match the required pattern.
        """

        if self.MODEL_REQUIRED is not None and re.match(self.MODEL_REQUIRED, self.llm.langchain_llm.model_name) is None:
            raise Exception(
                f"[eval_llm_ratp.ragas.chains.{self.name}.run] wrong model name ({self.llm.langchain_llm.model_name}) "
                f"(required model name: '{self.MODEL_REQUIRED}')"
            )

    def checks(self, inputs_list: list[dict]) -> None:
        """
        Performs various checks on the input data.

        """
        self._checks_dataset_required_keys(inputs_list)
        self._checks_model_required()

    async def output_parse(self, generations: list) -> list[t.Any]:
        """
        Parses the LLM output texts.

        Parameters
        ----------
        generations
            The list of generated outputs from the LLM.

        Returns
        -------
            The parsed outputs.
        """
        generations_text = [generation[0].text for generation in generations]
        outputs_parsed = [await self.output_parser(text) for text in generations_text]
        return outputs_parsed

    async def generate(
        self,
        inputs: dict,
        callbacks: t.Optional[Callbacks] = None,
    ) -> LLMResult:
        """
        Generates an output from the LLM based on the constructed prompt.

        Parameters
        ----------
        inputs
            The inputs for constructing the prompt.
        callbacks
            Callbacks to be invoked during the generation process, by default None

        Returns
        -------
            The result of the generation process, including parsed outputs.
        """
        self.checks([inputs])  # raise Exception if problems

        prompt = self.build_prompt(inputs)
        output = await self.llm.generate(prompt, callbacks=callbacks)
        outputs_parsed = await self.output_parse(output.generations)
        return outputs_parsed[0]


def json_loader_wrapper(llm: BaseRagasLLM) -> t.Callable[[str], t.Any]:
    """
    Wraps the JSON loader for safe loading.

    Parameters
    ----------
    llm
        The Ragas LLM instance to be used for loading JSON data.

    Returns
    -------
        A function that safely loads JSON data, using a retry mechanism to handle potential parsing errors,
        with the ability to generate new text through an LLM if initial parsing fails.
        This approach is aimed at ensuring that valid JSON data is extracted and loaded even in cases where the input may contain complex or nested JSON structures.

    """

    async def safe_load(text: str) -> t.Any:
        res = await json_loader.safe_load(text, llm)
        if not isinstance(res, list):
            res = [res]
        return res[-1]

    return safe_load


@dataclass
class JsonBaseChain(BaseChain):
    """
    An extension to BaseChain class that adapts the output parser for JSON format.
    It extracts and corrects JSON data from LLM outputs, ensuring that it can be safely loaded and used.

    """

    # find last json in text and fix the json if error
    def __post_init__(self) -> None:
        """Initializes the output parser to use the JSON loader wrapper."""
        self.output_parser = json_loader_wrapper(self.llm)
