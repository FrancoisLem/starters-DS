import typing as t


def only_keep_specified_keys_in_dict(data_list: list[dict], specified_keys: t.Union[list[str], set[str]]) -> list[dict]:
    return [{k: v for k, v in data.items() if k in specified_keys} for data in data_list]
