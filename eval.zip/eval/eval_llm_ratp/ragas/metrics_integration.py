import typing as t
from dataclasses import dataclass

import tqdm
from langfuse.client import DatasetItemClient

from eval.eval_llm_ratp.ragas.metrics.ground_truth.context.context_document_accuracy.context_document_accuracy import (
    ContextDocumentAccuracy,
)
from eval.eval_llm_ratp.ragas.metrics.ground_truth.context.context_document_completeness.context_document_completeness import (
    ContextDocumentCompleteness,
)

from .metrics import (
    AnswerAccuracy,
    RetrieveDocumentAccuracy,
    RetrieveDocumentCompleteness,
)
from .processing import Processing

if t.TYPE_CHECKING:
    from langfuse.callback import CallbackHandler

    from eval_llm_ratp.ragas.ragas_langfuse_decorator import (
        MetricRagasLangfuseDecorator,
    )


class AnswerAccuracyWithProcessing(AnswerAccuracy, Processing):
    """
    A class that combines the functionality of `AnswerAccuracy` and `Processing` for post-processing scores with additional information.
    This class is responsible for updating the current span with input and output information after computing the score.

    """

    def post_process(self, score: float, decorator: "MetricRagasLangfuseDecorator") -> float:
        score = super().post_process(score, decorator)

        # Update the span to add the inputs and outputs informations
        if self.current_span is not None and decorator.row is not None:
            self.current_span.update(
                name=self.name,
                input={
                    "answer": decorator.row["answer"],
                    "ground_truths": decorator.row["ground_truths"],
                },
                output={"score": score},
                metadata={"question": decorator.row["question"]},
            )

        return score


@dataclass
class RetrieveDocumentAccuracyWithProcessing(RetrieveDocumentAccuracy, Processing):
    """
    A class that combines the functionality of `RetrieveDocumentAccuracy` and `Processing` for post-processing scores with additional information.
    This class is responsible for updating the current span with input and output information after computing the score.

    """

    def post_process(self, score: float, decorator: "MetricRagasLangfuseDecorator") -> float:
        score = super().post_process(score, decorator)
        # create the metadata dict
        row = decorator.row
        metadata_inputs = row.copy()
        del metadata_inputs["contexts"]
        del metadata_inputs["ground_truths"]

        if self.current_span is not None and row is not None:
            self.current_span.update(
                name=self.name,
                startTime=self.startTime,
                input={
                    "contexts": row["contexts"],
                    "ground_truths": row["ground_truths"],
                },
                metadata={**metadata_inputs, "mode": self.mode.value},
                endTime=self.endTime,
                output={"score": score},
            )
        return score


@dataclass
class RetrieveDocumentCompletenessWithProcessing(RetrieveDocumentCompleteness, Processing):
    """
    A class that combines the functionality of `RetrieveDocumentCompleteness` and `Processing` for post-processing scores with additional information.
    This class is responsible for updating the current span with input and output information after computing the score.

    """

    def post_process(self, score: float, decorator: "MetricRagasLangfuseDecorator") -> float:
        score = super().post_process(score, decorator)
        # create the metadata dict
        row = decorator.row
        metadata_inputs = row.copy()
        del metadata_inputs["contexts"]
        del metadata_inputs["ground_truths"]

        if self.current_span is not None and row is not None:
            self.current_span.update(
                name=self.name,
                startTime=self.startTime,
                input={
                    "contexts": row["contexts"],
                    "ground_truths": row["ground_truths"],
                },
                metadata={
                    **metadata_inputs,
                },
                endTime=self.endTime,
                output={"score": score},
            )
        return score


@dataclass
class ContextDocumentAccuracyWithProcessing(ContextDocumentAccuracy, Processing):
    """
    A class that combines the functionality of `RetrieveDocumentAccuracy` and `Processing` for post-processing scores with additional information.
    This class is responsible for updating the current span with input and output information after computing the score.

    """

    def post_process(self, score: float, decorator: "MetricRagasLangfuseDecorator") -> float:
        score = super().post_process(score, decorator)
        # create the metadata dict
        row = decorator.row
        metadata_inputs = row.copy()
        del metadata_inputs["sources_context"]
        del metadata_inputs["ground_truths"]

        if self.current_span is not None and row is not None:
            self.current_span.update(
                name=self.name,
                startTime=self.startTime,
                input={
                    "sources_context": row["sources_context"],
                    "ground_truths": row["ground_truths"],
                },
                metadata={**metadata_inputs, "mode": self.mode.value},
                endTime=self.endTime,
                output={"score": score},
            )
        return score


@dataclass
class ContextDocumentCompletenessWithProcessing(ContextDocumentCompleteness, Processing):
    """
    A class that combines the functionality of `RetrieveDocumentCompleteness` and `Processing` for post-processing scores with additional information.
    This class is responsible for updating the current span with input and output information after computing the score.

    """

    def post_process(self, score: float, decorator: "MetricRagasLangfuseDecorator") -> float:
        score = super().post_process(score, decorator)
        # create the metadata dict
        row = decorator.row
        metadata_inputs = row.copy()
        del metadata_inputs["sources_context"]
        del metadata_inputs["ground_truths"]

        if self.current_span is not None and row is not None:
            self.current_span.update(
                name=self.name,
                startTime=self.startTime,
                input={
                    "sources_context": row["sources_context"],
                    "ground_truths": row["ground_truths"],
                },
                metadata={
                    **metadata_inputs,
                },
                endTime=self.endTime,
                output={"score": score},
            )
        return score


def score_with_ragas(
    metrics: list,
    item: DatasetItemClient,
    context: list[str],
    sources_context: list[str],
    answer: str,
    cb: "CallbackHandler",
) -> dict:
    scores = {}
    row = {
        "question": item.input["question"],
        "ground_truths": item.expected_output,
        "answer": answer,
        "contexts": context,
        "sources_context": sources_context,
        "source": item.input["source_name"],
    }

    for m in tqdm.tqdm(metrics, desc="score_with_ragas", position=2, leave=False):  # TODO: multiprocessing
        m.set_langfuse_cb(cb)
        scores[m.name] = m.score(row)

    return scores


def global_ragas_scores(scores: list[dict]) -> dict:
    import numpy as np

    global_scores = {
        f"{AnswerAccuracy.name}_mean": np.mean([score["ragas"][f"{AnswerAccuracy.name}"] for score in scores]),
        f"{AnswerAccuracy.name}_std": np.std([score["ragas"][f"{AnswerAccuracy.name}"] for score in scores]),
        f"{RetrieveDocumentAccuracy.name}_mean": np.mean(
            [score["ragas"][f"{RetrieveDocumentAccuracy.name}"] for score in scores]
        ),
        f"{RetrieveDocumentCompleteness.name}_mean": np.mean(
            [score["ragas"][f"{RetrieveDocumentCompleteness.name}"] for score in scores]
        ),
        f"{ContextDocumentAccuracy.name}_mean": np.mean([score["ragas"][f"{ContextDocumentAccuracy.name}"] for score in scores]),
        f"{ContextDocumentCompleteness.name}_mean": np.mean(
            [score["ragas"][f"{ContextDocumentCompleteness.name}"] for score in scores]
        ),
    }
    return global_scores
