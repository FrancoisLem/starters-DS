"""
This module integrates LangFuse callbacks with metric evaluation processes in the context of language model scoring systems.
It defines a context manager for setting LangFuse callbacks and a decorator class to augment metrics with additional functionality
for handling LangFuse callbacks, dataset processing, and batch operations.
"""

import typing as t
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass

from datasets import Dataset
from langchain_core.tracers.context import register_configure_hook
from langfuse.callback import CallbackHandler
from ragas.metrics.base import EvaluationMode, Metric

from .processing import MetricAndProcessing

if t.TYPE_CHECKING:
    from langchain.callbacks.base import Callbacks
    from ragas.llms import BaseRagasLLM

langfuse_callback_var = ContextVar("langfuse_callback", default=None)
register_configure_hook(langfuse_callback_var, True)


@contextmanager
def set_langfuse_callback(cb: CallbackHandler) -> t.Iterator[None]:
    """
    A context manager that sets a LangFuse callback within its context, ensuring that the callback is temporarily
    active for the duration of the context block and then reset to its previous state.

    Parameters:
        The LangFuse callback handler to be temporarily set.

    Yields:
        The function yields control back to the caller with the LangFuse callback set.
    """
    langfuse_callback_var.set(cb)
    yield
    langfuse_callback_var.set(None)


@dataclass
class MetricRagasLangfuseDecorator(Metric):
    """
    A decorator class that extends the functionality of metrics to seamlessly interact with LangFuse, enabling
    customized pre- and post-processing of data and integration with asynchronous scoring mechanisms.


    Attributes
    ----------
        metric
            The underlying metric to be enhanced.
        langfuse_callback
            The LangFuse callback handler for integration.
        dataset
            The dataset associated with the metric evaluation.
        batch_size
            The batch size for processing multiple evaluations.
    """

    metric: t.Optional[MetricAndProcessing] = None
    langfuse_callback: t.Optional[CallbackHandler] = None
    dataset: t.Optional[Dataset] = None
    batch_size: int = 0

    def _check_metric_is_set(self) -> None:
        if self.metric is None:
            raise Exception("[ragas_langfuse_decorator] metric is None")

    def score(self, row: dict, callbacks: "Callbacks" = None) -> float:
        """
        Evaluates the score of the metric for a given row, incorporating LangFuse callback handling and pre- and post-processing.

        Parameters
        ----------
        row
            The data row to be evaluated.
        callbacks
            Additional callbacks to be invoked during metric evaluation.

        Returns
        -------
            The evaluated score of the metric for the given row.

        Raises
        ------
            Exception ff the underlying metric is not set.
        """
        self._check_metric_is_set()
        # AUTOMATICALLY ADD LANGFUSE CB IN LANGCHAIN CHAINS
        with set_langfuse_callback(self.langfuse_callback):
            self.row = self.metric.pre_process(row, self)

            score = self.metric.score(self.row, callbacks=callbacks or [])

            return self.metric.post_process(score, self)

    async def _ascore(self, row: dict, callbacks: "Callbacks", is_async: bool) -> float:
        """
        Asynchronously evaluates the metric score for a given row, intended for use with asynchronous scoring mechanisms.

        Parameters
        ----------
        row
            The data row to be evaluated.
        callbacks
            Additional callbacks to be invoked during metric evaluation.
        is_async
            Indicates whether the evaluation is asynchronous.

        Returns
        -------
            float The asynchronously evaluated score of the metric for the given row.

        Raises
        ------
            Exception if the underlying metric is not set.
        """
        self._check_metric_is_set()
        # because we check with _check_metric_is_set
        return self.metric._ascore(row, callbacks=callbacks, is_async=is_async)

    def set_langfuse_cb(self, langfuse_callback: CallbackHandler) -> None:
        self.langfuse_callback = langfuse_callback

    # DECORATOR TO USE self.metric in methods
    def __post_init__(self) -> None:
        self._check_metric_is_set()
        self.batch_size = self.metric.batch_size

    @property
    def name(self) -> str:
        self._check_metric_is_set()
        return t.cast(str, self.metric.name)  # type: ignore[union-attr]

    @property
    def evaluation_mode(self) -> EvaluationMode:
        self._check_metric_is_set()
        return self.metric.evaluation_mode  # type: ignore[union-attr]

    def init(self, llm: "BaseRagasLLM | None" = None) -> None:
        self._check_metric_is_set()
        if hasattr(self.metric, "llm"):  # type: ignore[union-attr]
            self.metric.llm = llm  # type: ignore[union-attr]
            self.llm = llm
