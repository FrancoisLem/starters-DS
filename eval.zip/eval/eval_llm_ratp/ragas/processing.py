"""
This module implements an enhanced metric processing mechanism with pre- and post-processing capabilities,
designed to integrate with the LangFuse framework for span identification and tracking.
"""

import uuid
from datetime import datetime
from typing import TYPE_CHECKING

from ragas.metrics.base import Metric

if TYPE_CHECKING:
    from .ragas_langfuse_decorator import MetricRagasLangfuseDecorator


# Enhanced Metric class + Decorator
class Processing:
    """
    Class that provides methods for pre-processing and post-processing of data rows and metric scores,
    respectively, with special considerations for LangFuse span tracking and identification.

    """

    def pre_process(self, row: dict, decorator: "MetricRagasLangfuseDecorator") -> dict:
        """
        Performs pre-processing on the given row with LangFuse span tracking considerations.

        Parameters
        ----------
        row
            The data row to be processed.
        decorator
            The decorator providing LangFuse integration.

        Returns
        -------
            The processed data row, potentially modified or annotated for further processing.

        Side Effects
        ------------
            - Initializes the start time of processing.
            - Sets the next span ID in the LangFuse decorator, preparing it for the upcoming metric evaluation.
        """
        # Set the start time
        self.startTime = datetime.now()

        # Here we want to fix the next span id. The next span created by langfuse for the metric will have the "nextSpanId".
        decorator.nextSpanId = str(uuid.uuid4())  # SET THE NEXT SPAN ID FOR LANGFUSE TO
        if decorator.langfuse_callback is not None:
            decorator.langfuse_callback.setNextSpan(decorator.nextSpanId)  # SET THE NEXT SPAN ID TO THE LANGFUSE CALLBACK
        return row

    def post_process(self, score: float, decorator: "MetricRagasLangfuseDecorator") -> float:
        """
        Completes the processing of a metric score, handling span updates in the LangFuse context.

        Parameters
        ----------
            score
                The evaluated metric score to be post-processed.
            decorator
                The decorator with LangFuse integration.

        Returns
        -------
            The final metric score, potentially adjusted or validated through post-processing.

        Side Effects
        ------------
            - Marks the end time of processing.
            - Updates the relevant span in the LangFuse system with the current processing context.
        """
        # Set the end time
        self.endTime = datetime.now()

        # Find the span id corresponding to the current metric to update this span
        langfuse_callback = decorator.langfuse_callback  # GET THE LANGFUSE CALLBACK
        if langfuse_callback is not None:
            span_clients = [i for i in langfuse_callback.runs.values() if i.id == decorator.nextSpanId]
            self.current_span = None if len(span_clients) == 0 else span_clients[0]
        return score


class MetricAndProcessing(Metric, Processing):
    pass
