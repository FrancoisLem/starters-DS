import os

os.environ["RAGAS_DO_NOT_TRACK"] = "true"
