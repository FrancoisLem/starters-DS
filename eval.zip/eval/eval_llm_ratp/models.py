from iagen.back.engine.bot import RATPBot, Runnable


def get_pipeline() -> Runnable:
    """
    Initialize and return an instance of the RATPBot engine.

    Returns
    -------
    Runnable
        A Runnable of the RATPBot engine, fully initialized and ready to be used.
    """
    bot = RATPBot.get_engine(return_documents=True)
    return bot
