import typing as t

from dotenv import load_dotenv
from langchain_core._api import suppress_langchain_beta_warning

from eval_llm_ratp.dataset_adapter import create_dataset as create_dataset_adapter
from eval_llm_ratp.eval import run_eval as _run_eval
from eval_llm_ratp.langfuse.create_dataset import create_dataset_langfuse

load_dotenv()


def run_eval(
    experiment_name: str,
    dataset_name: str,
    n_runs: int = 3,
    filter_source: list[str] | None = None,
) -> None:
    with suppress_langchain_beta_warning():
        return _run_eval(experiment_name, dataset_name, n_runs, filter_source)


def create_dataset(
    filename: str,
    dataset_name: str,
    dataset_adapter_kwargs: dict[str, t.Any] | None = None,
) -> None:
    data = create_dataset_adapter(filename, **(dataset_adapter_kwargs or {}))

    assert isinstance(data["ground_truths"][0], list)  # noqa: S101
    assert isinstance(data["ground_truth_contexts"][0], list)  # noqa: S101

    create_dataset_langfuse(data, dataset_name)
    print("create_Dataset_ok", dataset_name)
